|logosub| CartAGen QGIS plugin
##############################

.. |logosub| image:: icons/icon.svg
    :height: 25px

A QGIS plugin providing a new toolbox from the `CartAGen Python library. <https://github.com/LostInZoom/cartagen>`_

Installation process is described `here. <https://cartagen.readthedocs.io/en/latest/qgis.html>`_