# cartagen - evaluation
This folder contains code for the evaluation of map generalisation, in particular for constraints monitors [introduced in the CollaGen model](http://dx.doi.org/10.1007/978-3-642-19143-5_30).
