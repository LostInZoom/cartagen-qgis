from cartagen.utils.partitioning.network import network_faces, partition_networks
from cartagen.utils.partitioning.tessellation import partition_grid, tessellate