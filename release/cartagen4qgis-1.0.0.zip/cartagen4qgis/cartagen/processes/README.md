# cartagen - algorithms
This folder will contain map generalisation processes, which orchestrate the algorithms available in this library.

The port of generalisation processes such as AGENT, or the least squares (from the [CartAGen library](https://github.com/IGNF/CartAGen)) is foreseen in the future.