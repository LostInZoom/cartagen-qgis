from cartagen.enrichment.urban.urban_areas import boffet_areas
