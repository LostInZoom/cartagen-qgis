# cartagen - algorithms
This folder contains map generalisation algorithms, most of them being ports from the [CartAGen library](https://github.com/IGNF/CartAGen).