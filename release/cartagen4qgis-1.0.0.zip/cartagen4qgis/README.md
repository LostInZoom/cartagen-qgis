# CartAGen4QGIS
A QGIS plugin provided tools from cartagen python library. Before installing this plugin, please install the [cartagen](https://pypi.org/project/cartagen/) library.