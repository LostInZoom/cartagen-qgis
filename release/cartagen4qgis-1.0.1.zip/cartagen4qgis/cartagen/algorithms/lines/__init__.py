from cartagen.algorithms.lines.bends import accordion, schematization
from cartagen.algorithms.lines.breaks import max_break, min_break